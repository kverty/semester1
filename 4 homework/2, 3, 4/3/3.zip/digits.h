#pragma once

bool isDigit(char c);
int charToInt(char c);
char intToChar(int c);
