#pragma once

int normalToAnswer(char normalExpression[], int length);
